###################
Username dan Password
###################



*******************
Admin
*******************

Username : admin@gmail.com


Password : admin123

**************************
Kader
**************************

Username : kader@gmail.com


Password : kader123

*******************
Kader lain
*******************

Username : kaderlain@gmail.com


password : kaderlain123

************
Bidan
************

Username :  bidan@gmail.com


Password : bidan123

