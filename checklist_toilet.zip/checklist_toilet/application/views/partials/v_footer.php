<footer class="main-footer">

    <strong>Copyright &copy; 2023 <a href="#">Sistem Checklist Kebersihan Toilet</a></strong>
</footer>

<aside class="control-sidebar control-sidebar-dark">
</aside>
</div>

<script src="<?php echo base_url('templates/plugins/jquery/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('templates/plugins/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
<script src="<?php echo base_url('templates/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js'); ?>"></script>
<script src="<?php echo base_url('templates/dist/js/adminlte.min.js'); ?>"></script>
<script src="<?php echo base_url('templates/plugins/datatables/jquery.dataTables.min.js'); ?>"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" />
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>

<!--<script type="text/javascript" src="<?php echo base_url('assets/js/jquery-3.4.1.min.js');?>"></script>-->
<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.bundle.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap-select.js');?>"></script>

</body>

</html>